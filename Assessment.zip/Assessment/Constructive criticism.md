# Constructive criticism

Criticism is a feedback given on a certain situation or occurence that usually is not in favour of the situation.
It is commonly known as negative feedback.

Constructive criticism is a critique given with a goal to make the situation better than it is rather than show how bad it is.

In other words, constructive criticism points out the mistake not to down look or shame the individual but make them better in their craft

An example,

Yesterday, i consulted a software developer on a ui of a certain project. His feedback was the UI was not good looking and greatly criticized my choice of colors.

That was a constructive criticism which pointed out on my failure but its core reason was to point my mistake to help correct it as well as be a better software developer.
