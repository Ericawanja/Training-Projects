function sum(arr) {
    return arr.reduce((a, b) => a + b);
  }
  console.log(sum([1,2,4,7]))